#define A 1
#define B 2
#define C 3
#define mul(x, y, z) ((x) * (y) * (z))