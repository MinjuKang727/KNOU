// [예제 4] 다음 코드의 공란에 적절한 내용을 넣어 완성하라.
#include <stdio.h>
#include <limits.h>
#include "myName.h"

int main() {
    Hello;
    short int minShrt = SHRT_MIN;   // short int형의 최솟값
    short int maxShrt = SHRT_MAX;   // short int형의 최댓값
    printf("short int의 크기: %zu\n", sizeof(short int));
    printf("short int 자료형 범위: %d ~ %d\n", minShrt, maxShrt);
}