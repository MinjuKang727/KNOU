#include "d.h"

int f(int x1, int x2, int x3) {
    return mul(x1 - A, x2 - B, x3 - C);
}