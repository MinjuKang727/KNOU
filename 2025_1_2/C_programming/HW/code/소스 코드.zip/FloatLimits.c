// [예제 4] 다음 코드의 공란에 적절한 내용을 넣어 완성하라.
#include <stdio.h>
#include <float.h>
#include "myName.h"

int main() {
    Hello;
    float minFlt = FLT_MIN;   // float형의 가장 미세한 값
    float maxFlt = FLT_MAX;   // float형의 가장 큰한 값
    printf("float의 크기: %zu\n", sizeof(float));
    printf("float 자료형 범위: %e ~ %e\n", minFlt, maxFlt);
}