// [예제 2] 문자열을 입력하고, “Hello, 입력문자열!” 형태로 출력하는 프로그램을 완성하라.
#include <stdio.h>
#include "myName.h"

int main() {
    Hello;
    char str[100];		// 문자열을 입력할 문자 배열
    printf("Who RU? ");
    scanf("%s", str);	// str에 문자열을 입력
    printf("Hello, %s!\n", str);	// “Hello, 입력문자열!” 출력
}